'use strict'
const express = require("express");
const app = express();
const router = express.Router();
const dirname = __dirname + '/views/';
const fs = require("fs");
const userJson = "user.json";
var obj = {
    User: []
};

fs.readFile(userJson, 'utf8', (err, data) => {
    data = JSON.parse(data);
    obj = data;
    console.log(obj);
});


//use css/js/img in folder public ex: <link href="/css/bootstrap.css" rel="stylesheet">
app.use(express.static('public'))

router.get("/", (req, res) => {
    res.sendFile(dirname + "index.html");
});

router.get("/about", (req, res) => {
    res.sendFile(dirname + "about.html");
});

router.get("/allCon", (req, res) => {
    res.sendFile(dirname + "allContact.html");
});

router.get("/test", (req, res) => {
    res.sendFile(dirname + "test.html");

});

router.get("/process_get", (req, res) => {
    obj.User.push({
        first_name: req.query.first_name,
        last_name: req.query.last_name,
        id: req.query.idName
    });
    let gbien = JSON.stringify(obj)
    fs.writeFile(userJson, gbien, (err) => {
        if (err) {
            console.log(err);
        } else {
            console.log("ghi file thanh cong");
        }
    });
    var temp = ''
    for (let number of obj.User) {
        temp += "F Name:" + number.first_name + " L Name:" + number.last_name + " ID: " + number.id + "</br>";
    }
    res.send(temp);
});


app.use("/", router);

app.use("*", (req, res) => {
    res.sendFile(dirname + "404.html");
});

//localhost:3000
app.listen(3000, () => {
    console.log("Website run on localhost:3000")
})