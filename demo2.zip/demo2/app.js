'use strict'
const express = require("express");
const app = express();
const router = express.Router();
const dirname = __dirname + '/views/';
const fs = require("fs");

var obj2 = '';
const cheerio = require('cheerio');
fs.readFile(dirname + 'allContact.html', 'utf8', (err, data) => {
    let $ = cheerio.load(data);
    $('div.test').text('olala')
    console.log($.html());

    // var bien = $('div#text').text('Hello there!').html();
    fs.writeFile(dirname + 'allContact.html', $.html(), function(err) {
        console.log('footer.html successfully written to HTML folder');
    });

});

// // var obj2 = {};
// let cheerio = require('cheerio')
// let $ = cheerio.load('<!DOCTYPE html><html lang="en"><head><meta charset="UTF-8"><meta name="viewport" content="width=device-width, initial-scale=1.0"><meta http-equiv="X-UA-Compatible" content="ie=edge"><title>Document</title></head><body><h1 class="abc">test</h1><h3 class="test">123</h3></body>')

// $('h3.test').text('olala')
// $('h3').addClass('welcome')
// console.log($.html());



const userJson = "user.json";
var obj = {
    User: []
};

fs.readFile(userJson, 'utf8', (err, data) => {
    data = JSON.parse(data);
    obj = data;
    // console.log(obj);
});


//use css/js/img in folder public ex: <link href="/css/bootstrap.css" rel="stylesheet">
app.use(express.static('public'))

router.get("/", (req, res) => {
    res.sendFile(dirname + "index.html");
});

router.get("/about", (req, res) => {
    res.sendFile(dirname + "about.html");
});


router.get("/allCon", (req, res) => {
    res.sendFile(dirname + "allContact.html");

    // $('#text').text('Hello there!');


    // var div = document.getElementById('text');
    // var temp = '';
    // for (let number of obj.User) {
    //     temp += "Name:" + number.full_name + " Email:" + number.user_Email + " Phone:" + number.user_phone + " Message:" + number.user_text + "</br>";
    // }
    // $.html();
    // div.innerHTML = temp;

});


router.get("/process_get", (req, res) => {
    obj.User.push({
        full_name: req.query.fullName,
        user_Email: req.query.userEmail,
        user_phone: req.query.userPhone,
        user_text: req.query.userText,
    });
    let gbien = JSON.stringify(obj)
    fs.writeFile(userJson, gbien, (err) => {
        if (err) {
            console.log(err);
        } else {
            console.log("ghi file thanh cong");
            res.sendFile(dirname + "allContact.html");
        }
    });
});

router.get('/:full_name', (req, res) => {
    fs.readFile(userJson, 'utf8', (err, data) => {
        data = JSON.parse(data);
        var use = data["User" + req.params.full_name];
        console.log(use);
        res.end(JSON.stringify(use));
    });
})

app.use("/", router);

app.use("*", (req, res) => {
    res.sendFile(dirname + "404.html");
});

//localhost:3000
app.listen(8081, () => {
    console.log("Website run on localhost:8080")
})