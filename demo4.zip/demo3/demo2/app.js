'use strict'
const express = require("express");
const app = express();
const router = express.Router();
const dirname = __dirname + '/views/';
const fs = require("fs");
const userJson = "user.json";
var obj = {
    User: []
};
const cheerio = require('cheerio');

fs.readFile(userJson, 'utf8', (err, data) => {
    data = JSON.parse(data);
    obj = data;
    // console.log(obj);
});

//use css/js/img in folder public ex: <link href="/css/bootstrap.css" rel="stylesheet">
app.use(express.static('public'))

router.get("/", (req, res) => {
    res.sendFile(dirname + "index.html");
});

router.get("/about", (req, res) => {
    res.sendFile(dirname + "about.html");
});


router.get("/allCon", (req, res) => {
    res.sendFile(dirname + "allContact.html");

    showAll();

});

app.get('/:name', function(req, res) {
    // First read existing users.
    let temp = '';
    for (let number of obj.User) {
        if (number.full_name = req.params.name) {
            temp =
                "<tr>" +
                "   <td>" + number.full_name + "</td>" +
                "   <td>" + number.user_Email + "</td>" +
                "   <td>" + number.user_phone + "</td>" +
                "   <td>" + number.user_text + "</td>" +
                "</tr>";
        }
    }
    console.log(temp);
    // res.send("tagId is set to " + req.params.name);
})



router.get("/process_get", (req, res) => {
    obj.User.push({
        full_name: req.query.fullName,
        user_Email: req.query.userEmail,
        user_phone: req.query.userPhone,
        user_text: req.query.userText,
    });
    let gbien = JSON.stringify(obj)
    fs.writeFile(userJson, gbien, (err) => {
        if (err) {
            console.log(err);
        } else {
            console.log("ghi file thanh cong");
            res.sendFile(dirname + "allContact.html");
        }
    });
    showAll();
    // fs.readFile(dirname + 'allContact.html', 'utf8', (err, data) => {
    //     var $ = cheerio.load(data);
    //     let temp = '';
    //     for (let number of obj.User) {
    //         temp +=
    //             "<tr>" +
    //             "   <td>" + number.full_name + "</td>" +
    //             "   <td>" + number.user_Email + "</td>" +
    //             "   <td>" + number.user_phone + "</td>" +
    //             "   <td>" + number.user_text + "</td>" +
    //             "</tr>";
    //     }
    //     console.log(temp);
    //     $('tbody#text').text(temp);
    //     fs.writeFile(dirname + 'allContact.html', $.html(), function(err) {
    //         console.log('footer.html successfully written to HTML folder');
    //     });

    // });
});

const showAll = () => {
    fs.readFile(dirname + 'allContact.html', 'utf8', (err, data) => {
        var $ = cheerio.load(data);
        let temp = '';
        for (let number of obj.User) {
            temp +=
                "<tr id='text'>" +
                "   <td>" + number.full_name + "</td>" +
                "   <td>" + number.user_Email + "</td>" +
                "   <td>" + number.user_phone + "</td>" +
                "   <td>" + number.user_text + "</td>" +
                "   <td><button type='button' id=" + number.full_name + " class='btn btn-default btnFix'>Detail</button><button type='button' id=" + number.full_name + " class='btn btn-default btnFix2'>delete</button></td>" +
                "</tr>";
        }

        // console.log(temp);
        const plum = $(temp)
        $('#text').replaceWith(plum)
            // $('tbody#text').appendTo(temp);
            // $(temp).appendTo('tbody#text')
        fs.writeFile(dirname + 'allContact.html', $.html(), function(err) {
            console.log('footer.html successfully written to HTML folder');
        });

    });
}


app.use("/", router);

app.use("*", (req, res) => {
    res.sendFile(dirname + "404.html");
});

//localhost:3000
app.listen(3000, () => {
    console.log("Website run on localhost:8080")
})
