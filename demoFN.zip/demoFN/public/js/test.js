var biengobal = '';
var test = (nametest) => {
    biengobal = nametest;
    document.getElementById("golBien").value = biengobal;
    // url: 'http://localhost:3000/endpoint',
}