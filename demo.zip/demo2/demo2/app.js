'use strict'
const express = require("express");
const app = express();
const router = express.Router();

const jsdom = require("jsdom");
const { JSDOM } = jsdom;
const dom = new JSDOM(__dirname + '/views/' + "showAll.html")

const dirname = __dirname + '/views/';
const fs = require("fs");
const userJson = "user.json";
var obj = {
    User: []
};

fs.readFile(userJson, 'utf8', (err, data) => {
    data = JSON.parse(data);
    obj = data;
    console.log(obj);
});

var showAllData = () => {

    let tbody = dom.window.document.querySelector("#showdata");
    let temp = '';
    for (let number of obj.User) {
        temp +=
            "<tr>" +
            "   <td>" + number.full_name + "</td>" +
            "   <td>" + number.user_Email + "</td>" +
            "   <td>" + number.user_phone + "</td>" +
            "   <td>" + number.user_text + "</td>" +
            "</tr>";
    }

    // console.log(temp);

    // $('#showdata').append(temp);

   tbody.innerHTML = temp;

}

//use css/js/img in folder public ex: <link href="/css/bootstrap.css" rel="stylesheet">
app.use(express.static('public'))

router.get("/", (req, res) => {
    res.sendFile(dirname + "index.html");
});

router.get("/about", (req, res) => {
    res.sendFile(dirname + "about.html");
});


router.get("/showAll", (req, res) => {
    res.sendFile(dirname + "showAll.html");

    

    showAllData();

});


router.get("/process_get", (req, res) => {
    obj.User.push({
        full_name: req.query.fullName,
        user_Email: req.query.userEmail,
        user_phone: req.query.userPhone,
        user_text: req.query.userText,
    });
    let gbien = JSON.stringify(obj)
    fs.writeFile(userJson, gbien, (err) => {
        if (err) {
            console.log(err);
        } else {
            console.log("ghi file thanh cong");
            res.sendFile(dirname + "showAll.html");
        }
    });

});


app.use("/", router);

app.use("*", (req, res) => {
    res.sendFile(dirname + "404.html");
});

//localhost:3000
app.listen(3000, () => {
    console.log("Website run on localhost:3000")
})
