setTimeout(function(){
    odometer.innerHTML = 32;
}, 2000);

setTimeout(function(){
    odometer2.innerHTML = 24;
}, 2000);

setTimeout(function(){
    odometer3.innerHTML = 24;
}, 2000);

setTimeout(function(){
    odometer4.innerHTML = 54;
}, 2000);