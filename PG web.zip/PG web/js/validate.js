 document.addEventListener("deviceready", onDeviceReady, true);

 function onDeviceReady() {

     $(document).ready(function() {
         $("#sub_login").bind("click", function() {
             validate();
         });
         $("#sub_regis").bind("click", function() {
             validateRegis();
         });

     });

 }

 function validate() {
     // alert("abc");
     var phoneID = document.getElementById("myPhone").value;
     var pass = document.getElementById("myPassword").value.trim();
     // alert(phoneID);

     if (phoneID === "") {
         $('#phoneNumber_error').text('Phone number not blank!');
         document.getElementById("myPhone").focus();

     } else {
         $('#phoneNumber_error').text('');
     }

     if (pass === "") {
         $('#pass_error').text('Password not blank!');
         document.getElementById("myPassword").focus();

     } else {
         $('#pass_error').text('');
     }

 }

 function validateRegis() {
 	 var name = document.getElementById("myName").value.trim();		
     var phoneID = document.getElementById("myPhone").value.trim();
     var pass = document.getElementById("myPassword").value.trim();
     var Repass = document.getElementById("myPassword").value.trim();
     // var dob = document.getElementById("dob").value.trim();
     // var addre = document.getElementById("Address").value.trim();
     // alert(phoneID);


     //name
     if (name === "") {
         $('#myName_error').text('Name not blank!');
         document.getElementById("myName").focus();

     } else {
         $('#myName_error').text('');
     }
	//name

	// phone
     if (phoneID === "") {
         $('#phoneNumber_error').text('Phone number not blank!');
         document.getElementById("myPhone").focus();

     } else {
         $('#phoneNumber_error').text('');
     }
     // phone

     // password
     if (pass === "") {
         $('#pass_error').text('Password not blank!');
         document.getElementById("myPassword").focus();

     } else {
         $('#pass_error').text('');
     }
     // password

     // Repassword
     if (Repass === "") {
         $('#myRePassword_error').text('Confirm Password not blank!');
         document.getElementById("myRePassword").focus();

     } else {
         $('#myRePassword_error').text('');
     }
     // Repassword

     // //date of birth
     // if (dob === "") {
     //     $('#dob_error').text('Date of birth not blank!');
     //     document.getElementById("dob").focus();

     // } else {
     //     $('#dob_error').text('');
     // }

     // //Address
     // if (addre === "") {
     //     $('#Add_error').text('Address not blank!');
     //     document.getElementById("Address").focus();

     // } else {
     //     $('#Add_error').text('');
     // }




 }
