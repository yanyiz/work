$(function() {

    var docao = $(window).height();
    var chieudai = $(window).width();
    var docao2 = docao / 3;

    $('.mauxanh').css({ 'height': docao });
    $('.mauxanh').css({ 'padding-top': docao2 });
    $('.mauxanh').css({ 'padding-bottom': docao2 });
    // $('.mauxanh').css({ 'padding-left': '100px' });
    // $('.mauxanh').css({ 'padding-right': '300px' });



    $('.mauvang').css({ 'height': docao });
    $('.mauvang').css({ 'padding-top': docao2 });
    $('.mauvang').css({ 'padding-bottom': docao2 });
    // $('.mauvang').css({ 'padding-left': '300px' });
    // $('.mauvang').css({ 'padding-right': '100px' });


    $(window).resize(function() {
        var docao = $(window).height();
        var docao2 = docao / 3 + "0";


        $('.mauxanh').css({ 'height': docao });
        $('.mauvang').css({ 'height': docao });
    });

    $('.btnAddEvent').hover(function() {
        $('.iconPlus').addClass('iconPlusAnima');
        
    }, function() {
        $('.iconPlus').removeClass('iconPlusAnima');
        
    })
     $('.btnAddEvent2').hover(function() {
        $('.iconPlus2').addClass('iconPlusAnima2');
        
    }, function() {
        $('.iconPlus2').removeClass('iconPlusAnima2');
        
    })


})

function openNav() {
    document.getElementById("myNav").style.height = "100%";
}

/* Close when someone clicks on the "x" symbol inside the overlay */
function closeNav() {
    document.getElementById("myNav").style.height = "0%";
}
